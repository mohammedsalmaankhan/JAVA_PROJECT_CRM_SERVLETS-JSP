package com.CRM;

public class contact{
	private String coname;
	private String coid;
	private String cophno;
	private String coemail;
	public String getConame() {
		return coname;
	}
	public void setConame(String coname) {
		this.coname = coname;
	}
	public String getCoid() {
		return coid;
	}
	public void setCoid(String coid) {
		this.coid = coid;
	}
	public String getCophno() {
		return cophno;
	}
	public void setCophno(String cophno) {
		this.cophno = cophno;
	}
	public String getCoemail() {
		return coemail;
	}
	public void setCoemail(String coemail) {
		this.coemail = coemail;
	}
	
}
