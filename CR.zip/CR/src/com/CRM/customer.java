package com.CRM;

public class customer {
private String cusname;
private String cusaddress;
private String cusid;
private String cusphno;
private String cuscity;
public String getCusname() {
	return cusname;
}
public void setCusname(String cusname) {
	this.cusname = cusname;
}
public String getCusaddress() {
	return cusaddress;
}
public void setCusaddress(String cusaddress) {
	this.cusaddress = cusaddress;
}
public String getCusid() {
	return cusid;
}
public void setCusid(String cusid) {
	this.cusid = cusid;
}
public String getCusphno() {
	return cusphno;
}
public void setCusphno(String cusphno) {
	this.cusphno = cusphno;
}
public String getCuscity() {
	return cuscity;
}
public void setCuscity(String cuscity) {
	this.cuscity = cuscity;
}

}
