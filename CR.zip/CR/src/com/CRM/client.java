package com.CRM;

public class client {
	private String clid;
	private String cliname;
	private String cliphno;
	private String cliaddress;
	private String companyname;
	public String getClid() {
		return clid;
	}
	public void setClid(String clid) {
		this.clid = clid;
	}
	public String getCliname() {
		return cliname;
	}
	public void setCliname(String cliname) {
		this.cliname = cliname;
	}
	public String getCliphno() {
		return cliphno;
	}
	public void setCliphno(String cliphno) {
		this.cliphno = cliphno;
	}
	public String getCliaddress() {
		return cliaddress;
	}
	public void setCliaddress(String cliaddress) {
		this.cliaddress = cliaddress;
	}
	public String getCompanyname() {
		return companyname;
	}
	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}
	
}
